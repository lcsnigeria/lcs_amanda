document.addEventListener("DOMContentLoaded", () => {
    const backdoorForm = document.getElementById("backdoor-form");
    if (backdoorForm) {
        backdoorForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const submitButton = backdoorForm.querySelector('#backdoor-action-btn');

            const activityState = submitButton.dataset.activity_state;

            if (!activityState) {
                alert('Unauthorized activity');
                return;
            }

            const formData = new FormData(backdoorForm);
            formData.append('action', '_amandaBackdoorProcessor');
            formData.append('activity_state', activityState);

            const ajaxRequest = new amandaAjaxRequest(formData);

            ajaxRequest.send()
                .then((response) => {
                    console.log(response);
                })
                .catch((error) => {
                    console.error("Error authenticating backdoor access:", error);
                })
        })
    }
})